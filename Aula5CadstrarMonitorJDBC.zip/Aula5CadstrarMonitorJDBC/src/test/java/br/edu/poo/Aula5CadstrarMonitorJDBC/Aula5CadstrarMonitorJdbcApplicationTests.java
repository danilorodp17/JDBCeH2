package br.edu.poo.Aula5CadstrarMonitorJDBC;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula5CadstrarMonitorJdbcApplicationTests {

	@Test
	void contextLoads() {
	}

}
