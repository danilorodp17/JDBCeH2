document.addEventListener("DOMContentLoaded", function() {
    if (document.getElementById("tabelaMonitores")) {
        listarMonitores();
    }
});

function listarMonitores() {
    fetch("/monitores/listar")
        .then(response => {
            if (!response.ok) {
                throw new Error("Erro ao carregar monitores");
            }
            return response.json();
        })
        .then(data => {
            const tabela = document.getElementById("tabelaMonitores").getElementsByTagName('tbody')[0];
            tabela.innerHTML = "";
            data.forEach(monitor => {
                const row = tabela.insertRow();
                row.insertCell(0).innerText = monitor.id;
                row.insertCell(1).innerText = monitor.nome;
                row.insertCell(2).innerText = monitor.tipo;
                row.insertCell(3).innerText = monitor.tamanho;
                row.insertCell(4).innerText = monitor.preco;

                const actionsCell = row.insertCell(5);
                actionsCell.innerHTML = `
                    <button onclick="excluirMonitor(${monitor.id})">Excluir</button>
                    <button onclick="preencherFormularioAlteracao(${monitor.id}, '${monitor.nome}', '${monitor.tipo}', '${monitor.tamanho}', '${monitor.preco}')">Alterar</button>
                `;
            });
        })
        .catch(error => {
            console.error("Erro ao carregar monitores:", error);
            alert("Erro ao carregar monitores");
        });
}

function excluirMonitor(id) {
    fetch(`/monitores/excluir/${id}`, {
        method: "DELETE"
    })
    .then(response => {
        if (response.ok) {
            alert("Monitor excluído com sucesso!");
            listarMonitores(); // Atualiza a lista de monitores
        } else {
            alert("Erro ao excluir monitor");
        }
    })
    .catch(error => {
        console.error("Erro ao excluir monitor:", error);
        alert("Erro ao excluir monitor");
    });
}

function preencherFormularioAlteracao(id, nome, tipo, tamanho, preco) {
    document.getElementById("formAlterar").style.display = 'block';
    document.getElementById("idAlterar").value = id;
    document.getElementById("nomeAlterar").value = nome;
    document.getElementById("tipoAlterar").value = tipo;
    document.getElementById("tamanhoAlterar").value = tamanho;
    document.getElementById("precoAlterar").value = preco;
}

function alterarMonitor() {
    const monitor = {
        id: document.getElementById("idAlterar").value,
        nome: document.getElementById("nomeAlterar").value,
        tipo: document.getElementById("tipoAlterar").value,
        tamanho: document.getElementById("tamanhoAlterar").value,
        preco: document.getElementById("precoAlterar").value
    };

    fetch("/monitores/atualizar", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(monitor)
    })
    .then(response => {
        if (response.ok) {
            alert("Monitor alterado com sucesso!");
            document.getElementById("formAlterar").style.display = 'none';
            listarMonitores(); // Atualiza a lista de monitores
        } else {
            alert("Erro ao alterar o monitor!");
        }
    })
    .catch(error => {
        console.error("Erro ao alterar o monitor:", error);
        alert("Erro ao alterar o monitor");
    });
}

function adicionarMonitor() {
    const monitor = {
        nome: document.getElementById("nome").value,
        tipo: document.getElementById("tipo").value,
        tamanho: document.getElementById("tamanho").value,
        preco: document.getElementById("preco").value
    };

    fetch("/monitores/adicionar", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(monitor)
    })
    .then(response => {
        if (response.ok) {
            alert("Monitor adicionado com sucesso!");
            document.getElementById("formAdicionar").reset(); // Limpa o formulário
        } else {
            alert("Erro ao adicionar monitor!");
        }
    })
    .catch(error => {
        console.error("Erro ao adicionar monitor:", error);
        alert("Erro ao adicionar monitor");
    });
}
