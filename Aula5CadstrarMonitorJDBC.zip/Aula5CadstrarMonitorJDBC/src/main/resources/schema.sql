CREATE TABLE monitores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    tipo VARCHAR(50),
    tamanho VARCHAR(20),
    preco VARCHAR(50)
);
