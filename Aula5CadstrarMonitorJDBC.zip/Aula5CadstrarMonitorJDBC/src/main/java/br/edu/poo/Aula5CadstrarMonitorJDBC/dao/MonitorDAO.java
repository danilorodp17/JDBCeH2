package br.edu.poo.Aula5CadstrarMonitorJDBC.dao;

import br.edu.poo.Aula5CadstrarMonitorJDBC.model.Monitor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;

@Repository
public class MonitorDAO {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    public void addMonitor(Monitor monitor) {
        String sql = "INSERT INTO monitores (nome, tipo, tamanho, preco) VALUES (?, ?, ?, ?)";
        jdbcTemplate.update(sql, monitor.getNome(), monitor.getTipo(), monitor.getTamanho(), monitor.getPreco());
    }

    public List<Monitor> listMonitores() {
        String sql = "SELECT * FROM monitores";
        return jdbcTemplate.query(sql, (rs, rowNum) -> {
            Monitor monitor = new Monitor();
            monitor.setId(rs.getInt("id"));
            monitor.setNome(rs.getString("nome"));
            monitor.setTipo(rs.getString("tipo"));
            monitor.setTamanho(rs.getString("tamanho"));
            monitor.setPreco(rs.getString("preco"));
            return monitor;
        });
    }

    public void updateMonitor(Monitor monitor) {
        String sql = "UPDATE monitores SET nome=?, tipo=?, tamanho=?, preco=? WHERE id=?";
        jdbcTemplate.update(sql, monitor.getNome(), monitor.getTipo(), monitor.getTamanho(), monitor.getPreco(), monitor.getId());
    }

    public void deleteMonitor(Long id) {
        String sql = "DELETE FROM monitores WHERE id=?";
        jdbcTemplate.update(sql, id);
    }
}
