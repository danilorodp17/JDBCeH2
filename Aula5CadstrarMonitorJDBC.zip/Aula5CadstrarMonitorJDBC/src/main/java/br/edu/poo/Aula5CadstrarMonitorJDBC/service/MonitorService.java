package br.edu.poo.Aula5CadstrarMonitorJDBC.service;

import br.edu.poo.Aula5CadstrarMonitorJDBC.dao.MonitorDAO;
import br.edu.poo.Aula5CadstrarMonitorJDBC.model.Monitor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class MonitorService {
    @Autowired
    private MonitorDAO monitorDAO;

    public void addMonitor(Monitor monitor) {
        monitorDAO.addMonitor(monitor);
    }

    public List<Monitor> listMonitores() {
        return monitorDAO.listMonitores();
    }

    public void updateMonitor(Monitor monitor) {
        monitorDAO.updateMonitor(monitor);
    }

    public void deleteMonitor(Long id) {
        monitorDAO.deleteMonitor(id);
    }
}
