package br.edu.poo.Aula5CadstrarMonitorJDBC.controler;

import br.edu.poo.Aula5CadstrarMonitorJDBC.dao.MonitorDAO;
import br.edu.poo.Aula5CadstrarMonitorJDBC.model.Monitor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/monitores")
public class MonitorController {
    @Autowired
    private MonitorDAO monitorDAO;

    @PostMapping("/adicionar")
    public String adicionarMonitor(@RequestBody Monitor monitor) {
        monitorDAO.addMonitor(monitor);
        return "Monitor adicionado com sucesso!";
    }

    @GetMapping("/listar")
    public List<Monitor> listarMonitores() {
        return monitorDAO.listMonitores();
    }

    @PutMapping("/atualizar")
    public String atualizarMonitor(@RequestBody Monitor monitor) {
        monitorDAO.updateMonitor(monitor);
        return "Monitor atualizado com sucesso!";
    }

    @DeleteMapping("/excluir/{id}")
    public String excluirMonitor(@PathVariable Long id) {
        monitorDAO.deleteMonitor(id);
        return "Monitor excluído com sucesso!";
    }
}
